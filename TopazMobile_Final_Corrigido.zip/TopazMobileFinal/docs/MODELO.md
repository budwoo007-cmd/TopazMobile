# Modelo de IA

O aplicativo baixa automaticamente na primeira execução o modelo Real-ESRGAN x4plus ONNX (~67 MB) para o armazenamento interno do aplicativo.

Isso evita colocar o arquivo binário de 67 MB dentro do ZIP do projeto. É necessário ter internet na primeira execução.

Depois do primeiro download, o modelo fica salvo localmente e é reutilizado.
