# Topaz Mobile

Projeto Android de super-resolução de vídeo usando Real-ESRGAN x4plus via ONNX Runtime.

## Como funciona
- O usuário escolhe um vídeo.
- O app baixa o modelo Real-ESRGAN x4plus na primeira execução, caso ele ainda não exista no armazenamento interno.
- Cada frame é dividido em blocos de 128x128 para controlar o uso de memória.
- O modelo faz super-resolução 4x e o resultado é redimensionado para o preset escolhido.
- A saída é MP4 e o app tenta preservar a faixa de áudio original.

## Presets
- 1080p: mantém a resolução do vídeo de origem quando ela já é menor ou igual ao alvo.
- 1440p: aumenta o maior eixo até 2560 px.
- 4K: aumenta o maior eixo até 3840 px.

## Modelo
O modelo usado é o Real-ESRGAN-x4plus ONNX da Qualcomm, com aproximadamente 67 MB. Ele é baixado automaticamente no primeiro processamento.

Observação: o desempenho depende muito do aparelho. Super-resolução de vídeo é pesada e pode demorar bastante em celulares sem aceleração adequada.
