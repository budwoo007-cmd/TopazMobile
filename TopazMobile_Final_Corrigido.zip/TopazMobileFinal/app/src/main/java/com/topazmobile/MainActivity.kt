package com.topazmobile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.topazmobile.engine.VideoEnhancer

class MainActivity : AppCompatActivity() {
    private var input: Uri? = null
    private lateinit var enhance: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private val pick = 10

    override fun onCreate(state: Bundle?) { super.onCreate(state); setContentView(R.layout.activity_main)
        val select = findViewById<Button>(R.id.selectButton); enhance = findViewById(R.id.enhanceButton); progress = findViewById(R.id.progress); status = findViewById(R.id.statusText)
        val spinner = findViewById<Spinner>(R.id.qualitySpinner)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("1080p • manter resolução original", "1440p • super-resolução", "4K • super-resolução"))
        select.setOnClickListener { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "video/*"; addCategory(Intent.CATEGORY_OPENABLE) }, pick) }
        enhance.setOnClickListener { val u=input ?: return@setOnClickListener; enhance.isEnabled=false; progress.progress=0; status.text="Iniciando IA..."; val mode=spinner.selectedItemPosition
            VideoEnhancer(this, u, mode, object: VideoEnhancer.Listener { override fun progress(p:Int, msg:String){ runOnUiThread{progress.progress=p;status.text=msg} }; override fun done(uri:Uri){runOnUiThread{enhance.isEnabled=true;status.text="Concluído: $uri"; Toast.makeText(this@MainActivity,"Vídeo salvo em Movies/TopazMobile",Toast.LENGTH_LONG).show()}}; override fun error(t:Throwable){runOnUiThread{enhance.isEnabled=true;status.text="Erro: ${t.message}";Toast.makeText(this@MainActivity,"Falha no processamento",Toast.LENGTH_LONG).show()}} }).execute()
        }
    }
    override fun onActivityResult(req:Int,res:Int,data:Intent?){super.onActivityResult(req,res,data); if(req==pick && res==Activity.RESULT_OK){input=data?.data; findViewById<TextView>(R.id.fileText).text=input?.toString(); enhance.isEnabled=input!=null}}
}
