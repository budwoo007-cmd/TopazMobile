package com.topazmobile.engine

import android.content.*
import android.graphics.*
import android.media.*
import android.net.Uri
import android.provider.MediaStore
import java.nio.ByteBuffer
import java.util.concurrent.Executors

class VideoEnhancer(private val ctx:Context, private val input:Uri, private val mode:Int, private val listener:Listener){
 interface Listener{fun progress(p:Int,msg:String);fun done(uri:Uri);fun error(t:Throwable)}
 fun execute(){Executors.newSingleThreadExecutor().execute{try{run()}catch(t:Throwable){listener.error(t)}}}
 private fun run(){
  val retriever=MediaMetadataRetriever(); retriever.setDataSource(ctx,input)
  val ex=MediaExtractor(); ctx.contentResolver.openFileDescriptor(input,"r")!!.use{ex.setDataSource(it.fileDescriptor)}
  var vi=-1;var ai=-1
  for(i in 0 until ex.trackCount){val f=ex.getTrackFormat(i); val m=f.getString(MediaFormat.KEY_MIME)?:"";if(m.startsWith("video/"))vi=i;if(m.startsWith("audio/"))ai=i}
  if(vi<0)throw IllegalStateException("Vídeo não encontrado")
  val vf=ex.getTrackFormat(vi); val ow=vf.getInteger(MediaFormat.KEY_WIDTH);val oh=vf.getInteger(MediaFormat.KEY_HEIGHT);val fps=if(vf.containsKey(MediaFormat.KEY_FRAME_RATE))vf.getInteger(MediaFormat.KEY_FRAME_RATE) else 30; val duration=if(vf.containsKey(MediaFormat.KEY_DURATION))vf.getLong(MediaFormat.KEY_DURATION) else 0L
  val outW=when(mode){1->((ow*4/3).coerceAtMost(2560));2->((ow*4).coerceAtMost(3840));else->ow}; val outH=(outW.toDouble()*oh/ow).toInt()
  val values=ContentValues().apply{put(MediaStore.Video.Media.DISPLAY_NAME,"Topaz_${System.currentTimeMillis()}.mp4");put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/TopazMobile")}
  val outUri=ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,values)!!;val pfd=ctx.contentResolver.openFileDescriptor(outUri,"rw")!!
  val mux=MediaMuxer(pfd.fileDescriptor,MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
  val enc=MediaCodec.createEncoderByType("video/avc");val fmt=MediaFormat.createVideoFormat("video/avc",outW,outH).apply{setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);setInteger(MediaFormat.KEY_BIT_RATE,(outW*outH*fps*0.08).toInt().coerceAtLeast(6_000_000));setInteger(MediaFormat.KEY_FRAME_RATE,fps);setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,2)}
  enc.configure(fmt,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);val surface=enc.createInputSurface();enc.start()
  var videoTrack=-1;var audioTrack=-1;var started=false
  val info=MediaCodec.BufferInfo()
  fun drain(end:Boolean=false){while(true){val id=enc.dequeueOutputBuffer(info,10_000);if(id==MediaCodec.INFO_TRY_AGAIN_LATER){if(!end)break}else if(id==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){videoTrack=mux.addTrack(enc.outputFormat);if(ai>=0)audioTrack=mux.addTrack(ex.getTrackFormat(ai));mux.start();started=true}else if(id>=0){val b=enc.getOutputBuffer(id)!!;if(info.size>0&&started){b.position(info.offset);b.limit(info.offset+info.size);mux.writeSampleData(videoTrack,b,info)};enc.releaseOutputBuffer(id,false);if(info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM!=0)break}}}
  val model=RealEsrgan(ctx); val frameStep=1_000_000L/fps; var t=0L
  while(t<duration){val bmp=retriever.getFrameAtTime(t,MediaMetadataRetriever.OPTION_CLOSEST)?:break;val up=model.upscale(bmp);val finalBmp=Bitmap.createScaledBitmap(up,outW,outH,true);val c=surface.lockCanvas(null);c.drawBitmap(finalBmp,null,Rect(0,0,outW,outH),null);surface.unlockCanvasAndPost(c);bmp.recycle();up.recycle();finalBmp.recycle();drain();t+=frameStep;listener.progress(((t*100)/duration).toInt().coerceIn(0,98),"IA: ${t/1_000_000}s / ${duration/1_000_000}s")}
  enc.signalEndOfInputStream();drain(true)
  if(started && ai>=0){val ae=MediaExtractor();ctx.contentResolver.openFileDescriptor(input,"r")!!.use{ae.setDataSource(it.fileDescriptor)};ae.selectTrack(ai);val ab=ByteArray(1024*1024);val bb=ByteBuffer.wrap(ab);val ai2=ae.getTrackFormat(ai);while(true){val size=ae.readSampleData(bb,0);if(size<0)break;val bi=MediaCodec.BufferInfo();bi.offset=0;bi.size=size;bi.presentationTimeUs=ae.sampleTime;bi.flags=ae.sampleFlags;bb.limit(size);mux.writeSampleData(audioTrack,bb,bi);bb.clear();ae.advance()};ae.release()}
  if(started)mux.stop();mux.release();enc.stop();enc.release();surface.release();model.close();retriever.release();ex.release();pfd.close();listener.progress(100,"Concluído");listener.done(outUri)
 }
}
